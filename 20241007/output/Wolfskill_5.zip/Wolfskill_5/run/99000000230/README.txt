runtype     : ensemble
 workflow id :  99000000027 
 ensemble id :  99000000018 
 run         :  1 / 10 
 run id      :  99000000230 
 pft names   :  temperate.deciduous 
 model       :  SIPNET 
 model id    :  99000000003 
 site        :  Wolfskill 
 site  id    :  99000000001 
 met data    :  /data/dbfiles/CRUNCEP_SIPNET_site_99-1/CRUNCEP.2006-01-01.2010-12-31.clim 
 start date  :  2006/01/01 
 end date    :  2010/12/31 
 hostname    :  localhost 
 rundir      :  /data/demo/workflows/Wolfskill_5/run/99000000230 
 outdir      :  /data/demo/workflows/Wolfskill_5/out/99000000230 
