#!/bin/bash

# redirect output
exec 3>&1
exec &> "/data/demo/workflows/Wolfskill_5/out/99000000233/logfile.txt"

# host specific setup


# cdo setup


# create output folder
mkdir -p "/data/demo/workflows/Wolfskill_5/out/99000000233"

# see if application needs running
if [ ! -e "/data/demo/workflows/Wolfskill_5/out/99000000233/sipnet.out" ]; then
  cd "/data/demo/workflows/Wolfskill_5/run/99000000233"
  ln -s "/data/dbfiles/CRUNCEP_SIPNET_site_99-1/CRUNCEP.2006-01-01.2010-12-31.clim" sipnet.clim

  "/usr/local/bin/sipnet.git"
  STATUS=$?
  
  # copy output
  mv "/data/demo/workflows/Wolfskill_5/run/99000000233/sipnet.out" "/data/demo/workflows/Wolfskill_5/out/99000000233"

  # check the status
  if [ $STATUS -ne 0 ]; then
  	echo -e "ERROR IN MODEL RUN\nLogfile is located at '/data/demo/workflows/Wolfskill_5/out/99000000233/logfile.txt'" >&3
  	exit $STATUS
  fi

  # convert to MsTMIP
  echo "require (PEcAn.SIPNET)
    model2netcdf.SIPNET('/data/demo/workflows/Wolfskill_5/out/99000000233', 38.5031763655516, -121.980793476105, '2006/01/01', '2010/12/31', FALSE, 'git')
    " | R --no-save
fi

# copy readme with specs to output
cp  "/data/demo/workflows/Wolfskill_5/run/99000000233/README.txt" "/data/demo/workflows/Wolfskill_5/out/99000000233/README.txt"

# run getdata to extract right variables

# host specific teardown


# all done
echo -e "MODEL FINISHED\nLogfile is located at '/data/demo/workflows/Wolfskill_5/out/99000000233/logfile.txt'" >&3
